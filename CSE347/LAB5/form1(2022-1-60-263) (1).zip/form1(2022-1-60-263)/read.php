<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Read Data</title>
    <link rel="stylesheet" href="stylenew.css">
</head>
<body>
    <?php
    include 'conn.php';  
    $sql = "SELECT * FROM users";
    $results = $conn->query($sql);

    if ($results->num_rows > 0) {
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Password</th><th>Phone</th><th>Age</th><th>Gender</th><th>Date of Birth</th><th>Address</th><th>Update/Delete</th></tr>";
        
        while ($row = $results->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["email"] . "</td>";
            echo "<td>" . $row["password"] . "</td>";
            echo "<td>" . $row["phone"] . "</td>";
            echo "<td>" . $row["age"] . "</td>";
            echo "<td>" . $row["gender"] . "</td>";
            echo "<td>" . $row["dateofbirth"] . "</td>";
            echo "<td>" . $row["address"] . "</td>";
            echo "<td>
                    <a href='update.php?updateid=" . $row["id"] . "'>Update</a>
                    <a href='delete.php?deleteid=" . $row["id"] . "'>Delete</a>
                  </td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No results found.";
    }

    $conn->close();
    ?>
</body>
</html>
