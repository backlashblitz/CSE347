<?php
include 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $dateofbirth = $_POST['dateofbirth'];
    $address = $_POST['address'];

    $sql = "INSERT INTO users (name, email, password, phone, age, gender, dateofbirth, address) 
            VALUES ('$name', '$email', '$password', '$phone', '$age', '$gender', '$dateofbirth', '$address')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
