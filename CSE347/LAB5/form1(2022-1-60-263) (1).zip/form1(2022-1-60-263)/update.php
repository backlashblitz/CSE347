<?php
include 'conn.php';

$id = $_GET['updateid'];

$sql = "SELECT * FROM users WHERE id=$id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['name'];
    $email = $row['email'];
    $password = $row['password'];
    $phone = $row['phone'];
    $age = $row['age'];
    $gender = $row['gender'];
    $dateofbirth = $row['dateofbirth'];
    $address = $row['address'];
} else {
    echo "No record found.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $dateofbirth = $_POST['dateoofbirth'];
    $address = $_POST['address'];

    $sql = "UPDATE users 
            SET name='$name', email='$email', password='$password',
                phone='$phone', age=$age, gender='$gender', 
                dateofbirth='$dateofbirth', address='$address'
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Updated successfully";
        header("Location: read.php"); 
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="form-class">
        <h1>Update User</h1>
        <form action="update.php?updateid=<?php echo $id; ?>" method="POST">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $name; ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $email; ?>" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" value="<?php echo $password; ?>" required>

            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" value="<?php echo $phone; ?>" required>

            <label for="age">Age:</label>
            <input type="number" id="age" name="age" value="<?php echo $age; ?>" required>

            <label for="gender">Gender:</label>
            <select id="gender" name="gender" required>
                <option value="Male" <?php if ($gender == 'Male') echo 'selected'; ?>>Male</option>
                <option value="Female" <?php if ($gender == 'Female') echo 'selected'; ?>>Female</option>
                <option value="Other" <?php if ($gender == 'Other') echo 'selected'; ?>>Other</option>
            </select>

            <label for="dateofbirth">Date of Birth:</label>
            <input type="date" id="dateofbirth" name="dateofbirth" value="<?php echo $dateofbirth; ?>" required>

            <label for="address">Address:</label>
            <textarea id="address" name="address" rows="3" required><?php echo $address; ?></textarea>

            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>
